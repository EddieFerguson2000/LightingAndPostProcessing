// Lab1.cpp
// Lab 1 example, simple coloured triangle mesh
#include "App1.h"

App1::App1()
{

}

void App1::init(HINSTANCE hinstance, HWND hwnd, int screenWidth, int screenHeight, Input *in, bool VSYNC, bool FULL_SCREEN)
{
	// Call super/parent init function (required!)
	BaseApplication::init(hinstance, hwnd, screenWidth, screenHeight, in, VSYNC, FULL_SCREEN);

	// Initalise scene variables.
	// Load texture.
	textureMgr->loadTexture(L"heightmap", L"res/heightmap4.png");
	textureMgr->loadTexture(L"sand", L"res/sandy.jpg");
	textureMgr->loadTexture(L"water", L"res/water.png");
	textureMgr->loadTexture(L"fish", L"res/fish.png");
	textureMgr->loadTexture(L"angler", L"res/angler.png");
	textureMgr->loadTexture(L"angler_alpha", L"res/angler_alpha.png");
	textureMgr->loadTexture(L"sun", L"res/sun2.jpg");
	textureMgr->loadTexture(L"sun_alpha", L"res/sun_alpha.jpg");
	textureMgr->loadTexture(L"torchOn", L"res/torch_on.png");
	textureMgr->loadTexture(L"torchOff", L"res/torch_off.png");
	textureMgr->loadTexture(L"torch_alpha", L"res/torch_alpha.png");
	textureMgr->loadTexture(L"waterMap", L"res/displacement_map.jpg");
	textureMgr->loadTexture(L"redNBlue", L"res/red_and_blue.jpg");
	textureMgr->loadTexture(L"pattern", L"res/kaleidoscope.png");
	textureMgr->loadTexture(L"shattered", L"res/broken.png");
	textureMgr->loadTexture(L"null", L"res/black.png");

	// Create objects
	mesh = new PlaneMesh(renderer->getDevice(), renderer->getDeviceContext());
	sun = new SphereMesh(renderer->getDevice(), renderer->getDeviceContext());
	water = new CubeMesh(renderer->getDevice(), renderer->getDeviceContext());
	lowerSand = new CubeMesh(renderer->getDevice(), renderer->getDeviceContext());
	heatWave = new CubeMesh(renderer->getDevice(), renderer->getDeviceContext());

	
	for (int i = 0; i < 7; i++)
	{
		fish[i] = new AModel(renderer->getDevice(), "res/fish.obj");
	}
	angler = new AModel(renderer->getDevice(), "res/angler.obj");
	torch_on = new AModel(renderer->getDevice(), "res/torch_on.obj");
	torch_off = new AModel(renderer->getDevice(), "res/torch_off.obj");

	waveboxShader = new WaveBoxShader(renderer->getDevice(), hwnd);
	shadowShader = new ShadowShader(renderer->getDevice(), hwnd);
	depthShader = new DepthShader(renderer->getDevice(), hwnd);
	textShader = new TextureShader(renderer->getDevice(), hwnd);
	hBlurShader = new HorizontalBlurShader(renderer->getDevice(), hwnd);
	aVBlurShader = new ActualVerticalBlurShader(renderer->getDevice(), hwnd);
	directionalBlurShader = new VerticalBlurShader(renderer->getDevice(), hwnd);
	zBlurShader = new ZoomBlurShader(renderer->getDevice(), hwnd);
	waterScreenEffect = new WaterScreen(renderer->getDevice(), hwnd);
	bloomShader = new BloomShader(renderer->getDevice(), hwnd);
	manipShader = new ManipulationShader(renderer->getDevice(), hwnd);
	lightShader = new LightShader(renderer->getDevice(), hwnd);

	
	orthoMesh = new OrthoMesh(renderer->getDevice(), renderer->getDeviceContext(), screenWidth , screenHeight);
	//orthoMesh = new OrthoMesh(renderer->getDevice(), renderer->getDeviceContext(), screenWidth , screenHeight, -(0.01*screenWidth),0.01*screenHeight);
	orthoMesh2 = new OrthoMesh(renderer->getDevice(), renderer->getDeviceContext(), screenWidth / 2, screenHeight / 2);	// Full screen size
	
	renderTexture = new RenderTexture(renderer->getDevice(), screenWidth, screenHeight, SCREEN_NEAR, SCREEN_DEPTH);
	zBlurTexture = new RenderTexture(renderer->getDevice(), screenWidth, screenHeight, SCREEN_NEAR, SCREEN_DEPTH);
	directionalBlurTexture = new RenderTexture(renderer->getDevice(), screenWidth, screenHeight, SCREEN_NEAR, SCREEN_DEPTH);
	hBlurTexture = new RenderTexture(renderer->getDevice(), screenWidth, screenHeight, SCREEN_NEAR, SCREEN_DEPTH);
	aVBlurTexture = new RenderTexture(renderer->getDevice(), screenWidth, screenHeight, SCREEN_NEAR, SCREEN_DEPTH);
	waterPPTexture = new RenderTexture(renderer->getDevice(), screenWidth, screenHeight, SCREEN_NEAR, SCREEN_DEPTH);
	bloomPassTexture = new RenderTexture(renderer->getDevice(), screenWidth, screenHeight, SCREEN_NEAR, SCREEN_DEPTH);
	bloomTexture = new RenderTexture(renderer->getDevice(), screenWidth, screenHeight, SCREEN_NEAR, SCREEN_DEPTH);


	//init shadowMap variables
	int shadowmapWidth = 4096;
	int shadowmapHeight = 4096;
	int sceneWidth = 300;
	int sceneHeight = 300;
	shadowMap = new ShadowMap(renderer->getDevice(), shadowmapWidth, shadowmapHeight);
	shadowMap2 = new ShadowMap(renderer->getDevice(), shadowmapWidth, shadowmapHeight);

	
	// Initialising all lights

	//Sun
	light = new Light();
	light->setAmbientColour(0.2f, 0.2f, 0.4f, 1.0f);
	light->setDiffuseColour(0.4f, 0.4f, 0.8f, 1.0f);
	light->setPosition(0.0f, 100.0f, 0.0f);
	light->generateOrthoMatrix((float)sceneWidth, (float)sceneHeight, 0.01f, 175.f);
	//torch 
	torch = new Light();
	torch->setAmbientColour(0.0f, 0.0f, 0.0f, 1.0f);
	torch->setDiffuseColour(0.1f, 0.1f, 0.1f, 1.0f);
	torch->setPosition(0.0f, 0.0f, 0.0f);
	torch->generateProjectionMatrix(10.f, 100.f);
	torch->generateOrthoMatrix((float)sceneWidth, (float)sceneHeight, 0.01f, 100.f);

	//volcano
	volcanoLight = new Light();
	volcanoLight->setAmbientColour(0.0f, 0.0f, 0.0f, 1.0f);
	volcanoLight->setDiffuseColour(1.0f, 0.0f, 0.0f, 0.2f);
	volcanoLight->setPosition(16.99f, 5.f, 15.88f);

	//angler fish
	anglerLight = new Light();
	anglerLight->setAmbientColour(0.0f, 0.0f, 0.0f, 1.0f);
	anglerLight->setDiffuseColour(0.0f, 1.0f, 0.0f, 1.0f);
	anglerLight->setPosition(0.0f, 5.0f, 0.0f);
	time = 0.f;

	//Initialising camera
	camera->setPosition(50.f, 25.f, -75.f);
	camera->setRotation(1.f, 0.f, 0.f);
	l2Y = 0.1;
	l2Z = 120;
	angXYZ[0] = 0.1;
	angXYZ[1] = 100.f;

	//initialise lighting stuff
	linF = 0.f;
	quadF = 0.06f;


	D3D11_RASTERIZER_DESC ncdesc;
	ZeroMemory(&ncdesc, sizeof(D3D11_RASTERIZER_DESC));
	ncdesc.FillMode = D3D11_FILL_SOLID;
	ncdesc.CullMode = D3D11_CULL_NONE;
	renderer->getDevice()->CreateRasterizerState(&ncdesc, &NoCullFrame);
	renderer->getDeviceContext()->RSSetState(NoCullFrame);
	
	D3D11_RASTERIZER_DESC bcdesc;
	ZeroMemory(&bcdesc, sizeof(D3D11_RASTERIZER_DESC));
	bcdesc.FillMode = D3D11_FILL_SOLID;
	bcdesc.CullMode = D3D11_CULL_FRONT;
	renderer->getDevice()->CreateRasterizerState(&bcdesc, &BackCullFrame);
	renderer->getDeviceContext()->RSSetState(BackCullFrame);
}


App1::~App1()
{
	// Run base application deconstructor
	BaseApplication::~BaseApplication();

	// Release the Direct3D object.
	if (mesh)
	{
		delete mesh;
		mesh = 0;
	}
	for (int i = 0; i < 7; i++)
	{
		if (fish[i])
		{
			delete fish[i];
			fish[i] = 0;
		}
	}
	if (angler)
	{
		delete angler;
		angler = 0;
	}
	if (torch_on)
	{
		delete torch_on;
			torch_on = 0;
	}
	if (torch_off)
	{
		delete torch_off;
		torch_off = 0;
	}	
	if (water)
	{
		delete water;
		water = 0;
	}
	if (sun)
	{
		delete sun;
		sun = 0;
	}
	if (lowerSand)
	{
		delete lowerSand;
		lowerSand = 0;
	}

	if (waveboxShader)
	{
		delete waveboxShader;
		waveboxShader = 0;
	}
	if (shadowShader)
	{
		delete shadowShader;
		shadowShader = 0;
	}
	if (depthShader)
	{
		delete depthShader;
		depthShader = 0;
	}
	if (textShader)
	{
		delete textShader;
		textShader = 0;
	}
	if (hBlurShader)
	{
		delete hBlurShader;
		hBlurShader = 0;
	}
	if (aVBlurShader)
	{
		delete aVBlurShader;
		aVBlurShader = 0;
	}
	if (directionalBlurShader)
	{
		delete directionalBlurShader;
		directionalBlurShader = 0;
	}
	if (zBlurShader)
	{
		delete zBlurShader;
		zBlurShader = 0;
	}
	if (waterScreenEffect)
	{
		delete waterScreenEffect;
		waterScreenEffect = 0;
	}
	if (bloomShader)
	{
		delete bloomShader;
		bloomShader = 0;
	}
	if (manipShader)
	{
		delete manipShader;
		manipShader = 0;
	}
	if (lightShader)
	{
		delete lightShader;
		lightShader = 0;
	}
}


bool App1::frame()
{
	bool result;

	result = BaseApplication::frame();
	if (!result)
	{
		return false;
	}
	
	//update most time-based things
	update();
	// Render the graphics.
	result = render();
	if (!result)
	{
		return false;
	}
	
	return true;
}


void App1::update()
{
	time += timer->getTime();

	//change the suns brightness (as a light, not bloom), based on user input
	light->setAmbientColour(0.2f * sunBrightness, 0.2f * sunBrightness, 0.4f * sunBrightness, 1.0f);
	light->setDiffuseColour(0.4f * sunBrightness, 0.4f * sunBrightness, 0.8f * sunBrightness, 1.0f);

	//Changing the position of the sun light (goes around in a circle, always points towards centre)
	lightX = 50.f + (142.f * sin(time / 5));
	lightZ = 50.f + (142.f * cos(time / 5));
	float vecLength = sqrt((lightX * lightX) + (l2Y * l2Y) + (lightZ * lightZ));
	light->setPosition(lightX, -10.f, lightZ);
	light->setDirection(-lightX / vecLength, -0.7, -lightZ / vecLength);

	//Changing the position of the Angler Fish light (ALSO goes around in a circle)
	anglerLight->setPosition(50.f + (7.071f * sin(time / 5 + 1.5)), 5.f, 50.f + (7.071f * cos(time / 5 + 1.5)));

	// getting forward vector of the camera to give to the spotlight as its direction
	XMVECTOR forward;
	forward = camera->getViewMatrix().r[0];
	pitch = XMVectorGetZ(forward);
	forward = camera->getViewMatrix().r[1];
	yaw = XMVectorGetZ(forward);
	forward = camera->getViewMatrix().r[2];
	roll = XMVectorGetZ(forward);

	//Updates torch light's position and direction ONLY if the player is "Holding" it
	if (torchControl == true)
	{
		torch->setPosition(camera->getPosition().x, camera->getPosition().y, camera->getPosition().z);
		torch->setDirection(pitch, yaw, roll);
	}
	//Generates new matrices based on the new angle
	torch->generateOrthoMatrix(300.f, 300.f, angXYZ[0], angXYZ[1]);
	torch->generateProjectionMatrix(angXYZ[0], angXYZ[1]);

	//Changes the light from the torch depending on whether its on or off
	if (torchOn == true)
	{
		torch->setDiffuseColour(0.1f, 0.1f, 0.1f, 1.0f);
	}
	else
	{

		torch->setDiffuseColour(0.f, 0.f, 0.f, 1.f);
	}

	if (blurCheck == true)
	{
		//This changes how potent the bluring effect is depending on how long you've been underwater
		if (moving == true && underWaterTimer > 10)
		{
			underWaterTimer -= timer->getTime() * 2;
		}
		else
		{
			if (underWaterTimer < 50)
			{
				underWaterTimer += timer->getTime() * 10;
			}
		}
	}
	else
	{
		//If you're out of the water, reset the blur effect so that when you go back in it'll be all blurry again
		underWaterTimer = 1.f;
	}
}

bool App1::render()
{
	//check to see if the blur stages should take place based on UI check box and also whether the player is in underwater
	checkForBlur();

	//Perform the depth pass
	depthPass();

	//Perform initial pass (or final if no post processing)
	firstPass();

	//Perform post processing if blur is activated
	if (blurCheck == true)
	{
		//Perform all the post processing passes AND the final pass
		postProcessing();
	}
	

	//render UI
	gui();

	// Present the rendered scene to the screen.
	renderer->endScene();
	

	return true;
}

//Depth pass for shadows. Checks depth for the torch light and the sun/moon light
void App1::depthPass()
{
	
	light->generateViewMatrix();
	XMMATRIX lightViewMatrix = light->getViewMatrix();
	XMMATRIX lightProjectionMatrix = light->getOrthoMatrix();
	
	renderer->setZBuffer(true);

	XMMATRIX worldMatrix = renderer->getWorldMatrix();
	XMMATRIX translateMatrix = XMMatrixTranslation(0.f, 1.05f, 0.f);
	//FIRST LIGHT (FROM THE SUN) Creates depthmap used for shadows from the suns perspective
	{
		shadowMap->BindDsvAndSetNullRenderTarget(renderer->getDeviceContext());

		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);

		//Sandy hills
		mesh->sendData(renderer->getDeviceContext());
		depthShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, lightViewMatrix, lightProjectionMatrix, textureMgr->getTexture(L"heightmap"), true);
		depthShader->render(renderer->getDeviceContext(), mesh->getIndexCount());

		//fish matrix
		worldMatrix = renderer->getWorldMatrix();
		XMMATRIX scaleMatrix = XMMatrixScaling(0.5f, 0.5f, 0.5f);
		translateMatrix = XMMatrixTranslation(20.f, 0.f, 20.f);
		XMMATRIX rotateMatrix = XMMatrixRotationY(5.9);
		worldMatrix = XMMatrixMultiply(worldMatrix, scaleMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		rotateMatrix = XMMatrixRotationY(time / 10);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);

		XMMATRIX temp = worldMatrix;

		//fish
		for (int i = 0; i < 7; i++)
		{
			if (i == 0)
			{
				translateMatrix = XMMatrixTranslation(50.f, 20.f, 53.f);
			}
			else if (i == 1)
			{
				translateMatrix = XMMatrixTranslation(50.f, 23.5f, 48.f);
			}
			else if (i == 2)
			{
				translateMatrix = XMMatrixTranslation(51.f, 20.5f, 50.f);
			}
			else if (i == 3)
			{
				translateMatrix = XMMatrixTranslation(54.f, 19.f, 49.f);
			}
			else if (i == 4)
			{
				translateMatrix = XMMatrixTranslation(52.f, 18.5f, 52.f);
			}
			else if (i == 5)
			{
				translateMatrix = XMMatrixTranslation(49.f, 20.f, 51.f);
			}
			else if (i == 6)
			{
				translateMatrix = XMMatrixTranslation(47.f, 21.f, 51.f);
			}

			worldMatrix = XMMatrixMultiply(temp, translateMatrix);
			fish[i]->sendData(renderer->getDeviceContext());
			depthShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, lightViewMatrix, lightProjectionMatrix, textureMgr->getTexture(L"heightmap"), false);
			depthShader->render(renderer->getDeviceContext(), fish[i]->getIndexCount());
		}

		//Angler fish matrix
		worldMatrix = renderer->getWorldMatrix();
		scaleMatrix = XMMatrixScaling(1.f, 1.f, 1.f);
		translateMatrix = XMMatrixTranslation(5.f, 0.f, 5.f);
		worldMatrix = XMMatrixMultiply(worldMatrix, scaleMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		translateMatrix = XMMatrixTranslation(50.f, 10.f, 50.f);
		rotateMatrix = XMMatrixRotationY(time / 5);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		angler->sendData(renderer->getDeviceContext());
		depthShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, lightViewMatrix, lightProjectionMatrix, textureMgr->getTexture(L"angler"), false);
		depthShader->render(renderer->getDeviceContext(), angler->getIndexCount());

		renderer->setBackBufferRenderTarget();
		renderer->resetViewport();
	}

	torch->generateViewMatrix();
	torch->generateProjectionMatrix(cls, 100.f);

	XMMATRIX torchViewMatrix = torch->getViewMatrix();
	XMMATRIX torchProjectionMatrix = torch->getProjectionMatrix();
	XMMATRIX torchOrthoMatrix = torch->getOrthoMatrix();
	
	//SECOND LIGHT (FROM PLAYER TORCH) Creates depthmap used for shadows from the torchs perspective
	{
		shadowMap2->BindDsvAndSetNullRenderTarget(renderer->getDeviceContext());

		worldMatrix = renderer->getWorldMatrix();
		translateMatrix = XMMatrixTranslation(0.f, 1.05f, 0.f);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		
		//Sandy hills
		mesh->sendData(renderer->getDeviceContext());
		depthShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, torchViewMatrix, torchOrthoMatrix, textureMgr->getTexture(L"heightmap"), true);
		depthShader->render(renderer->getDeviceContext(), mesh->getIndexCount());

		//fish matrix
		worldMatrix = renderer->getWorldMatrix();
		XMMATRIX scaleMatrix = XMMatrixScaling(0.5f, 0.5f, 0.5f);
		translateMatrix = XMMatrixTranslation(20.f, 0.f, 20.f);
		XMMATRIX rotateMatrix = XMMatrixRotationY(5.9);
		worldMatrix = XMMatrixMultiply(worldMatrix, scaleMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		rotateMatrix = XMMatrixRotationY(time / 10);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);

		XMMATRIX temp = worldMatrix;

		//fish
		for (int i = 0; i < 7; i++)
		{
			if (i == 0)
			{
				translateMatrix = XMMatrixTranslation(50.f, 20.f, 53.f);
			}
			else if (i == 1)
			{
				translateMatrix = XMMatrixTranslation(50.f, 23.5f, 48.f);
			}
			else if (i == 2)
			{
				translateMatrix = XMMatrixTranslation(51.f, 20.5f, 50.f);
			}
			else if (i == 3)
			{
				translateMatrix = XMMatrixTranslation(54.f, 19.f, 49.f);
			}
			else if (i == 4)
			{
				translateMatrix = XMMatrixTranslation(52.f, 18.5f, 52.f);
			}
			else if (i == 5)
			{
				translateMatrix = XMMatrixTranslation(49.f, 20.f, 51.f);
			}
			else if (i == 6)
			{
				translateMatrix = XMMatrixTranslation(47.f, 21.f, 51.f);
			}

			worldMatrix = XMMatrixMultiply(temp, translateMatrix);
			fish[i]->sendData(renderer->getDeviceContext());
			if (torchOrtho == true)
			{
				depthShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, torchViewMatrix, torchOrthoMatrix, textureMgr->getTexture(L"heightmap"), false);
			}
			else
			{
				depthShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, torchViewMatrix, torchProjectionMatrix, textureMgr->getTexture(L"heightmap"), false);
			}
			depthShader->render(renderer->getDeviceContext(), fish[i]->getIndexCount());
		}

		//Angler fish matrix
		worldMatrix = renderer->getWorldMatrix();
		scaleMatrix = XMMatrixScaling(1.f, 1.f, 1.f);
		translateMatrix = XMMatrixTranslation(5.f, 0.f, 5.f);
		worldMatrix = XMMatrixMultiply(worldMatrix, scaleMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		translateMatrix = XMMatrixTranslation(50.f, 10.f, 50.f);
		rotateMatrix = XMMatrixRotationY(time / 5);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		angler->sendData(renderer->getDeviceContext());
		if (torchOrtho == true)
		{
			depthShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, torchViewMatrix, torchOrthoMatrix, textureMgr->getTexture(L"angler"), false);
		}
		else
		{
			depthShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, torchViewMatrix, torchProjectionMatrix, textureMgr->getTexture(L"angler"), false);
		}
		depthShader->render(renderer->getDeviceContext(), angler->getIndexCount());

		renderer->setBackBufferRenderTarget();
		renderer->resetViewport();
	}
	
}

//This is the final pass if blur/post processing is turned off. Renders the whole scene, lights, shadows and all.
void App1::firstPass()
{
	//If blur is turned on, this pass will be turned into a texture to be sent for the next pass
	if (blurCheck == true)
	{
		renderTexture->setRenderTarget(renderer->getDeviceContext());
		renderTexture->clearRenderTarget(renderer->getDeviceContext(), 0.39f, 0.58f, 0.92f, 1.0f);
	}

	renderer->beginScene(0.39f, 0.58f, 0.92f, 1.0f);

	XMMATRIX worldMatrix, viewMatrix, projectionMatrix;

	XMMATRIX scaleMatrix;
	XMMATRIX rotateMatrix;

	camera->update();

	// Get the world, view, projection, and ortho matrices from the camera and Direct3D objects.
	worldMatrix = renderer->getWorldMatrix();
	viewMatrix = camera->getViewMatrix();
	projectionMatrix = renderer->getProjectionMatrix();
	renderer->setZBuffer(true);
	renderer->getDeviceContext()->RSSetState(BackCullFrame);

	// Send geometry data, set shader parameters, render object with shader
	XMMATRIX translateMatrix = XMMatrixTranslation(0.f, 1.05f, 0.f);
	worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);

	//Sandy hills, lit with all four lights, casts shadows onto itself using the torch and sunlight
	mesh->sendData(renderer->getDeviceContext());
	shadowShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"heightmap"), textureMgr->getTexture(L"sand"), shadowMap->getDepthMapSRV(), shadowMap2->getDepthMapSRV(), light, torch, anglerLight, volcanoLight, constF, linF, quadF, torchOn, true);
	shadowShader->render(renderer->getDeviceContext(), mesh->getIndexCount());

	//fish matrix (they rotate swim in a circle around the centre of the scene)
	{
		worldMatrix = renderer->getWorldMatrix();
		scaleMatrix = XMMatrixScaling(0.5f, 0.5f, 0.5f);
		translateMatrix = XMMatrixTranslation(20.f, 0.f, 20.f);
		rotateMatrix = XMMatrixRotationY(5.9);
		worldMatrix = XMMatrixMultiply(worldMatrix, scaleMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		rotateMatrix = XMMatrixRotationY(time / 10);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);
	}

	XMMATRIX temp = worldMatrix;

	//fish
	for (int i = 0; i < 7; i++)
	{
		if (i == 0)
		{
			translateMatrix = XMMatrixTranslation(50.f, 20.f, 53.f);
		}
		else if (i == 1)
		{
			translateMatrix = XMMatrixTranslation(50.f, 23.5f, 48.f);
		}
		else if (i == 2)
		{
			translateMatrix = XMMatrixTranslation(51.f, 20.5f, 50.f);
		}
		else if (i == 3)
		{
			translateMatrix = XMMatrixTranslation(54.f, 19.f, 49.f);
		}
		else if (i == 4)
		{
			translateMatrix = XMMatrixTranslation(52.f, 18.5f, 52.f);
		}
		else if (i == 5)
		{
			translateMatrix = XMMatrixTranslation(49.f, 20.f, 51.f);
		}
		else if (i == 6)
		{
			translateMatrix = XMMatrixTranslation(47.f, 21.f, 51.f);
		}

		worldMatrix = XMMatrixMultiply(temp, translateMatrix);
		fish[i]->sendData(renderer->getDeviceContext());

		//All seven fish use light from all 4 light sources. They also cast shadows on themselves, though thats really hard to see
		shadowShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"heightmap"), textureMgr->getTexture(L"fish"), shadowMap->getDepthMapSRV(), shadowMap2->getDepthMapSRV(), light, torch, anglerLight, volcanoLight, constF, linF, quadF, torchOn, false);
		shadowShader->render(renderer->getDeviceContext(), fish[i]->getIndexCount());
	}



	//sun matrix
	{
		worldMatrix = renderer->getWorldMatrix();
		scaleMatrix = XMMatrixScaling(10.f, 10.f, 10.f);
		translateMatrix = XMMatrixTranslation(100.f, 0.f, 100.f);
		worldMatrix = XMMatrixMultiply(worldMatrix, scaleMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		translateMatrix = XMMatrixTranslation(50.f, 20.f, 50.f);
		rotateMatrix = XMMatrixRotationY((time / 5) - 1);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		sun->sendData(renderer->getDeviceContext());
		//No lighting is applied to this. Its the sun.
		textShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"sun"));
		textShader->render(renderer->getDeviceContext(), sun->getIndexCount());
	}

	
	


	//Angler fish matrix
	{
		worldMatrix = renderer->getWorldMatrix();
		scaleMatrix = XMMatrixScaling(1.f, 1.f, 1.f);
		translateMatrix = XMMatrixTranslation(5.f, 0.f, 5.f);
		worldMatrix = XMMatrixMultiply(worldMatrix, scaleMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		translateMatrix = XMMatrixTranslation(50.f, 10.f, 50.f);
		rotateMatrix = XMMatrixRotationY(time / 5);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		angler->sendData(renderer->getDeviceContext());
		shadowShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"heightmap"), textureMgr->getTexture(L"angler"), shadowMap->getDepthMapSRV(), shadowMap2->getDepthMapSRV(), light, torch, anglerLight, volcanoLight, constF, linF, quadF, torchOn, false);
		shadowShader->render(renderer->getDeviceContext(), angler->getIndexCount());
	}
	
	//If the player is holding the torch it will follow the camera around and turn with it.
	if (torchControl == true)
	{
		torchTranslate[0] = camera->getPosition().x + (pitch * 4);
		torchTranslate[1] = camera->getPosition().y + (yaw * 4) - 2;
		
			torchTranslate[2] = camera->getPosition().z + (roll * 4);


		torchRotate[0] = (camera->getRotation().x * (3.1416 / 180)) + 1.5708;
		torchRotate[1] = camera->getRotation().y * (3.1416 / 180);
	}

	//torch model matrix
	{
		worldMatrix = renderer->getWorldMatrix();
		scaleMatrix = XMMatrixScaling(0.5f, 0.5f, 0.5f);
		translateMatrix = XMMatrixTranslation(torchTranslate[0], torchTranslate[1], torchTranslate[2]);
		rotateMatrix = XMMatrixRotationRollPitchYaw(torchRotate[0], torchRotate[1], 0);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, scaleMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		
		//A different model and texture are used if the torch is on or off
		if (torchOn == true)
		{
			torch_on->sendData(renderer->getDeviceContext());
			shadowShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"heightmap"), textureMgr->getTexture(L"torchOn"), shadowMap->getDepthMapSRV(), shadowMap2->getDepthMapSRV(), light, torch, anglerLight, volcanoLight, constF, linF, quadF, false, false);

			shadowShader->render(renderer->getDeviceContext(), angler->getIndexCount());
		}
		else
		{
			torch_off->sendData(renderer->getDeviceContext());
			shadowShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"heightmap"), textureMgr->getTexture(L"torchOff"), shadowMap->getDepthMapSRV(), shadowMap2->getDepthMapSRV(), light, torch, anglerLight, volcanoLight, constF, linF, quadF, false, false);

			shadowShader->render(renderer->getDeviceContext(), angler->getIndexCount());
		}
		
	}
	


	//Back face culling is turned off for the water so that you can see it while inside it.
	renderer->getDeviceContext()->RSSetState(NoCullFrame);

	//water
	{
		worldMatrix = renderer->getWorldMatrix();
		renderer->setAlphaBlending(true);
		scaleMatrix = XMMatrixScaling(50.f, 30.f, 50.f);
		translateMatrix = XMMatrixTranslation(50.f, 15.f, 50.f);
		worldMatrix = XMMatrixMultiply(worldMatrix, scaleMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		water->sendData(renderer->getDeviceContext());
		waveboxShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"water"), time, freq, ampl, spe);
		waveboxShader->render(renderer->getDeviceContext(), water->getIndexCount());
		renderer->setAlphaBlending(false);
	}

	renderer->getDeviceContext()->RSSetState(BackCullFrame);


	//Sand box (stuff below the sandy hills
	{
		worldMatrix = renderer->getWorldMatrix();
		scaleMatrix = XMMatrixScaling(50.05f, 6.f, 50.05f);
		translateMatrix = XMMatrixTranslation(50.f, -5.f, 50.f);
		worldMatrix = XMMatrixMultiply(worldMatrix, scaleMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		lowerSand->sendData(renderer->getDeviceContext());
		//Simple lighting is applied to this from the sun.
		lightShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"sand"), light);
		lightShader->render(renderer->getDeviceContext(), lowerSand->getIndexCount());
	}

	worldMatrix = renderer->getWorldMatrix();


	// Present the rendered scene to the screen.
	if (blurCheck == false) // If no blurring has been turned off, simply end the scene
	{
		renderer->endScene();
	}
	else // Otherwise, set the back buffer render target
	{
		renderer->setBackBufferRenderTarget();
	}



}

//Check if the blur post processing has been turned off
void App1::checkForBlur()
{
	if (camera->getPosition().x >= 0.f && camera->getPosition().y >= 0.f && camera->getPosition().z >= 0.f)
	{
		if (camera->getPosition().x <= 100.f && camera->getPosition().y <= 50.f && camera->getPosition().z <= 100.f)
		{
			blurCheck = true;
		}
		else
		{
			blurCheck = false;
		}
	}
	else
	{
		blurCheck = false;
	}
}

//Calls all the necessary post processing functions
void App1::postProcessing()
{
	
	bloomPass();
	horizontalBlur();
	verticalBlur();
	//This is a bit of a mess... Just trust me, it handles which effects are put on depending on the checklist of booleans in the UI
	{
		if (bloomEffect == true)
		{
			bloom();

			if (waterEffect == true)
			{
				waterPPEffect(bloomTexture);
				blurInputs();
				if (motBlurEffect == true)
				{

					directionalBlur(waterPPTexture);
					if (zoomBlurEffect == true)
					{
						zoomBlur(directionalBlurTexture);
						finalPass(zBlurTexture);
					}
					else
					{
						finalPass(directionalBlurTexture);
					}

				}
				else
				{
					if (zoomBlurEffect == true)
					{
						zoomBlur(waterPPTexture);
						finalPass(zBlurTexture);
					}
					else
					{
						finalPass(waterPPTexture);
					}

				}
			}
			else
			{
				blurInputs();
				if (motBlurEffect == true)
				{
					directionalBlur(bloomTexture);
					if (zoomBlurEffect == true)
					{
						zoomBlur(directionalBlurTexture);
						finalPass(zBlurTexture);
					}
					else
					{
						finalPass(directionalBlurTexture);
					}

				}
				else
				{
					if (zoomBlurEffect == true)
					{
						zoomBlur(bloomTexture);
						finalPass(zBlurTexture);
					}
					else
					{
						finalPass(bloomTexture);
					}

				}
			}
		}
		else
		{
			if (waterEffect == true)
			{
				waterPPEffect(renderTexture);
				blurInputs();
				if (motBlurEffect == true)
				{
					directionalBlur(waterPPTexture);
					if (zoomBlurEffect == true)
					{
						zoomBlur(directionalBlurTexture);
						finalPass(zBlurTexture);
					}
					else
					{
						finalPass(directionalBlurTexture);
					}

				}
				else
				{
					if (zoomBlurEffect == true)
					{
						zoomBlur(waterPPTexture);
						finalPass(zBlurTexture);
					}
					else
					{
						finalPass(waterPPTexture);
					}
				}
			}
			else
			{
				blurInputs();
				if (motBlurEffect == true)
				{
					directionalBlur(renderTexture);
					if (zoomBlurEffect == true)
					{
						zoomBlur(directionalBlurTexture);
						finalPass(zBlurTexture);
					}
					else
					{
						finalPass(directionalBlurTexture);
					}

				}
				else
				{
					if (zoomBlurEffect == true)
					{
						zoomBlur(renderTexture);

						finalPass(zBlurTexture);

					}
					else
					{
						finalPass(renderTexture);
					}
				}
			}
		}
	}
	
	
}

//This is a pass that renders everything except the sun, angler fish and torch in pure black.
//Those 3 exceptions are rendered with a texture that ONLY has the parts that are meant to be sources of light coloured, the rest is black
void App1::bloomPass()
{
	bloomPassTexture->setRenderTarget(renderer->getDeviceContext());
	bloomPassTexture->clearRenderTarget(renderer->getDeviceContext(), 0.0f, 0.0f, 0.f, 1.0f);

	renderer->beginScene(0.0f, 0.0f, 0.0f, 1.0f);
	XMMATRIX worldMatrix, viewMatrix, projectionMatrix;

	camera->update();
	worldMatrix = renderer->getWorldMatrix();
	viewMatrix = camera->getViewMatrix();
	projectionMatrix = renderer->getProjectionMatrix();

	renderer->setZBuffer(true);

	XMMATRIX scaleMatrix;
	XMMATRIX rotateMatrix;
	XMMATRIX translateMatrix;

	// Send geometry data, set shader parameters, render object with shader
	translateMatrix = XMMatrixTranslation(0.f, 1.05f, 0.f);
	worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
	//Sandy hills
	mesh->sendData(renderer->getDeviceContext());
	manipShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"heightmap"), textureMgr->getTexture(L"null"));
	manipShader->render(renderer->getDeviceContext(), mesh->getIndexCount());


	//fish matrix
	{
		worldMatrix = renderer->getWorldMatrix();
		scaleMatrix = XMMatrixScaling(0.5f, 0.5f, 0.5f);
		translateMatrix = XMMatrixTranslation(20.f, 0.f, 20.f);
		rotateMatrix = XMMatrixRotationY(5.9);
		worldMatrix = XMMatrixMultiply(worldMatrix, scaleMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		rotateMatrix = XMMatrixRotationY(time / 10);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);
	}

	XMMATRIX temp = worldMatrix;

	//fish
	for (int i = 0; i < 7; i++)
	{
		if (i == 0)
		{
			translateMatrix = XMMatrixTranslation(50.f, 20.f, 53.f);
		}
		else if (i == 1)
		{
			translateMatrix = XMMatrixTranslation(50.f, 23.5f, 48.f);
		}
		else if (i == 2)
		{
			translateMatrix = XMMatrixTranslation(51.f, 20.5f, 50.f);
		}
		else if (i == 3)
		{
			translateMatrix = XMMatrixTranslation(54.f, 19.f, 49.f);
		}
		else if (i == 4)
		{
			translateMatrix = XMMatrixTranslation(52.f, 18.5f, 52.f);
		}
		else if (i == 5)
		{
			translateMatrix = XMMatrixTranslation(49.f, 20.f, 51.f);
		}
		else if (i == 6)
		{
			translateMatrix = XMMatrixTranslation(47.f, 21.f, 51.f);
		}

		worldMatrix = XMMatrixMultiply(temp, translateMatrix);
		fish[i]->sendData(renderer->getDeviceContext());
		textShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"null"));

		textShader->render(renderer->getDeviceContext(), fish[i]->getIndexCount());
	}

	//sun matrix
	{
		worldMatrix = renderer->getWorldMatrix();
		scaleMatrix = XMMatrixScaling(10.f, 10.f, 10.f);
		translateMatrix = XMMatrixTranslation(100.f, 0.f, 100.f);
		worldMatrix = XMMatrixMultiply(worldMatrix, scaleMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		translateMatrix = XMMatrixTranslation(50.f, 20.f, 50.f);
		rotateMatrix = XMMatrixRotationY((time / 5) - 1);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		sun->sendData(renderer->getDeviceContext());
		textShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"sun_alpha"));
		textShader->render(renderer->getDeviceContext(), sun->getIndexCount());
	}

	//If the player is holding the torch it will follow the camera around and turn with it.
	if (torchControl == true)
	{
		torchTranslate[0] = camera->getPosition().x + (pitch * 4);
		torchTranslate[1] = camera->getPosition().y + (yaw * 4) - 2;

		torchTranslate[2] = camera->getPosition().z + (roll * 4);


		torchRotate[0] = (camera->getRotation().x * (3.1416 / 180)) + 1.5708;
		torchRotate[1] = camera->getRotation().y * (3.1416 / 180);
	}
	//torch model matrix
	{
		worldMatrix = renderer->getWorldMatrix();
		scaleMatrix = XMMatrixScaling(0.5f, 0.5f, 0.5f);
		translateMatrix = XMMatrixTranslation(torchTranslate[0], torchTranslate[1], torchTranslate[2]);
		rotateMatrix = XMMatrixRotationRollPitchYaw(torchRotate[0], torchRotate[1], 0);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, scaleMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);

		//A different model and texture are used if the torch is on or off
		if (torchOn == true)
		{
			torch_on->sendData(renderer->getDeviceContext());
			textShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"torch_alpha"));


			textShader->render(renderer->getDeviceContext(), angler->getIndexCount());
		}
		else
		{
			torch_off->sendData(renderer->getDeviceContext());
			textShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"null"));

			textShader->render(renderer->getDeviceContext(), angler->getIndexCount());
		}

	}


	//Angler fish matrix
	{
		worldMatrix = renderer->getWorldMatrix();
		scaleMatrix = XMMatrixScaling(1.f, 1.f, 1.f);
		translateMatrix = XMMatrixTranslation(5.f, 0.f, 5.f);
		worldMatrix = XMMatrixMultiply(worldMatrix, scaleMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		translateMatrix = XMMatrixTranslation(50.f, 10.f, 50.f);
		rotateMatrix = XMMatrixRotationY(time / 5);
		worldMatrix = XMMatrixMultiply(worldMatrix, rotateMatrix);
		worldMatrix = XMMatrixMultiply(worldMatrix, translateMatrix);
		angler->sendData(renderer->getDeviceContext());
		textShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, viewMatrix, projectionMatrix, textureMgr->getTexture(L"angler_alpha"));
		textShader->render(renderer->getDeviceContext(), angler->getIndexCount());
	}

	renderer->setBackBufferRenderTarget();

}

//The horizontal aspect of blur post processing
void App1::horizontalBlur()
{
	XMMATRIX worldMatrix, baseViewMatrix, orthoMatrix;

	float screenSizeX = (float)directionalBlurTexture->getTextureWidth();
	hBlurTexture->setRenderTarget(renderer->getDeviceContext());
	hBlurTexture->clearRenderTarget(renderer->getDeviceContext(), 1.0f, 1.0f, 0.0f, 1.0f);

	worldMatrix = renderer->getWorldMatrix();
	baseViewMatrix = camera->getOrthoViewMatrix();
	orthoMatrix = directionalBlurTexture->getOrthoMatrix();

	// Render for Horizontal Blur
	renderer->setZBuffer(false);
	orthoMesh->sendData(renderer->getDeviceContext());
	hBlurShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, baseViewMatrix, orthoMatrix, bloomPassTexture->getShaderResourceView(), screenSizeX, bloomMult);
	hBlurShader->render(renderer->getDeviceContext(), orthoMesh->getIndexCount());
	renderer->setZBuffer(true);

	// Reset the render target back to the original back buffer and not the render to texture anymore.
	renderer->setBackBufferRenderTarget();
}

//The verticle aspect of blur post processing
void App1::verticalBlur()
{
	XMMATRIX worldMatrix, baseViewMatrix, orthoMatrix;

	float screenSizeY = (float)directionalBlurTexture->getTextureWidth();
	aVBlurTexture->setRenderTarget(renderer->getDeviceContext());
	aVBlurTexture->clearRenderTarget(renderer->getDeviceContext(), 1.0f, 1.0f, 0.0f, 1.0f);

	worldMatrix = renderer->getWorldMatrix();
	baseViewMatrix = camera->getOrthoViewMatrix();
	orthoMatrix = directionalBlurTexture->getOrthoMatrix();

	// Render for Horizontal Blur
	renderer->setZBuffer(false);
	orthoMesh->sendData(renderer->getDeviceContext());
	aVBlurShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, baseViewMatrix, orthoMatrix, hBlurTexture->getShaderResourceView(), screenSizeY, bloomMult);
	aVBlurShader->render(renderer->getDeviceContext(), orthoMesh->getIndexCount());
	renderer->setZBuffer(true);

	// Reset the render target back to the original back buffer and not the render to texture anymore.
	renderer->setBackBufferRenderTarget();
}

//Essentially applies a blur to certain lights and nothing else. Doesn't really work that well as a bloom... But I tried
void App1::bloom()
{
	XMMATRIX worldMatrix, baseViewMatrix, orthoMatrix;

	float screenSizeY = (float)directionalBlurTexture->getTextureHeight();
	float screenSizeX = (float)directionalBlurTexture->getTextureWidth();
	bloomTexture->setRenderTarget(renderer->getDeviceContext());
	bloomTexture->clearRenderTarget(renderer->getDeviceContext(), 0.0f, 0.0f, 0.0f, 1.0f);

	worldMatrix = renderer->getWorldMatrix();
	baseViewMatrix = camera->getOrthoViewMatrix();
	// Get the ortho matrix from the render to texture since texture has different dimensions being that it is smaller.
	orthoMatrix = directionalBlurTexture->getOrthoMatrix();

	// Render for Vertical Blur
	renderer->setZBuffer(false);
	orthoMesh->sendData(renderer->getDeviceContext());
	bloomShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, baseViewMatrix, orthoMatrix, aVBlurTexture->getShaderResourceView(), renderTexture->getShaderResourceView(), screenSizeX, screenSizeY);
	bloomShader->render(renderer->getDeviceContext(), orthoMesh->getIndexCount());
	renderer->setZBuffer(true);

	// Reset the render target back to the original back buffer and not the render to texture anymore.
	renderer->setBackBufferRenderTarget();
}

//Plurs the screen using a watery image. Only applies under water. Very extreme when just entering water/moving around
void App1::waterPPEffect(RenderTexture* tex)
{
	XMMATRIX worldMatrix, baseViewMatrix, orthoMatrix;

	float screenSizeY = (float)directionalBlurTexture->getTextureHeight();
	float screenSizeX = (float)directionalBlurTexture->getTextureWidth();
	waterPPTexture->setRenderTarget(renderer->getDeviceContext());
	waterPPTexture->clearRenderTarget(renderer->getDeviceContext(), 0.0f, 1.0f, 1.0f, 1.0f);

	worldMatrix = renderer->getWorldMatrix();
	baseViewMatrix = camera->getOrthoViewMatrix();
	// Get the ortho matrix from the render to texture since texture has different dimensions being that it is smaller.
	orthoMatrix = directionalBlurTexture->getOrthoMatrix();

	// Render for Vertical Blur
	renderer->setZBuffer(false);
	orthoMesh->sendData(renderer->getDeviceContext());
	//Send a different image depending on the one selected in the UI
	if (waterBlurImage == 1)
	{
		waterScreenEffect->setShaderParameters(renderer->getDeviceContext(), worldMatrix, baseViewMatrix, orthoMatrix, tex->getShaderResourceView(), textureMgr->getTexture(L"waterMap"), screenSizeY, screenSizeX, underWaterTimer, time, timer->getTime(), goggles, waterBlurImage);
	}
	else if (waterBlurImage == 2)
	{
		waterScreenEffect->setShaderParameters(renderer->getDeviceContext(), worldMatrix, baseViewMatrix, orthoMatrix, tex->getShaderResourceView(), textureMgr->getTexture(L"redNBlue"), screenSizeY, screenSizeX, underWaterTimer, time, timer->getTime(), goggles, waterBlurImage);
	}
	else if (waterBlurImage == 3)
	{
		waterScreenEffect->setShaderParameters(renderer->getDeviceContext(), worldMatrix, baseViewMatrix, orthoMatrix, tex->getShaderResourceView(), textureMgr->getTexture(L"pattern"), screenSizeY, screenSizeX, underWaterTimer, time, timer->getTime(), goggles, waterBlurImage);
	}
	else if (waterBlurImage == 4)
	{
		waterScreenEffect->setShaderParameters(renderer->getDeviceContext(), worldMatrix, baseViewMatrix, orthoMatrix, tex->getShaderResourceView(), textureMgr->getTexture(L"shattered"), screenSizeY, screenSizeX, underWaterTimer, time, timer->getTime(), goggles, waterBlurImage);
	}
	waterScreenEffect->render(renderer->getDeviceContext(), orthoMesh->getIndexCount());
	renderer->setZBuffer(true);

	// Reset the render target back to the original back buffer and not the render to texture anymore.
	renderer->setBackBufferRenderTarget();
}

//Finding the direction and distance of blur based on inputs
void App1::blurInputs()
{
	
	float blurAng = 0;
	bool left = false;
	bool right = false;
	bool up = false;
	bool down = false;

	//A bunch of inputs that decide which direction the blur should be and how blurred it should be
	{
		if (input->isKeyDown('D') || input->isKeyDown(VK_RIGHT))
		{
			right = true;
		}
		else
		{
			right = false;
		}

		if (input->isKeyDown('A') || input->isKeyDown(VK_LEFT))
		{
			left = true;
		}
		else
		{
			left = false;
		}

		if (input->isKeyDown('E') || input->isKeyDown(VK_UP))
		{
			up = true;
		}
		else
		{
			up = false;
		}

		if (input->isKeyDown('Q') || input->isKeyDown(VK_DOWN))
		{
			down = true;
		}
		else
		{
			down = false;
		}

		if ((right && left))
		{
			if (!(down || up))
			{
				moving = false;
			}
			else if (down && !up)
			{
				moving = true;
			}
			else if (up && !down)
			{
				moving = true;
			}
			else if ((down && up))
			{
				moving = false;
			}
		}
		else if ((right && !left))
		{
			moving = true;
			if (!(down || up))
			{
				blurAng = 180;
			}
			else if (down && !up)
			{
				blurAng = 225;
			}
			else if (up && !down)
			{
				blurAng = 135;
			}
			else if ((down && up))
			{
				blurAng = 180;
			}
		}
		else if ((!right && left))
		{
			moving = true;
			if (!(down || up))
			{
				blurAng = 0;
			}
			else if (down && !up)
			{
				blurAng = 315;
			}
			else if (up && !down)
			{
				blurAng = 45;
			}
			else if ((down && up))
			{
				blurAng = 0;
			}
		}

		if ((down && input->isKeyDown('W')))
		{
			if (!(right || left))
			{
				moving = false;
			}
			else if (right && !left)
			{
				blurAng = 180;
				moving = true;
			}
			else if (left && !right)
			{
				blurAng = 0;
				moving = true;
			}
			else if ((right && left))
			{
				moving = false;
			}
		}
		else if ((!down && up))
		{
			moving = true;
			if (!(right || left))
			{
				blurAng = 90;
			}
			else if (right && !left)
			{
				blurAng = 135;
			}
			else if (left && !right)
			{
				blurAng = 45;
			}
			else if ((right && left))
			{
				blurAng = 90;
			}
		}
		else if ((down && !up))
		{
			moving = true;
			if (!(right || left))
			{
				blurAng = 270;
			}
			else if (right && !left)
			{
				blurAng = 225;
			}
			else if (left && !right)
			{
				blurAng = 315;
			}
			else if ((right && left))
			{
				blurAng = 270;
			}
		}

		if (!(right || left || (down || up)))
		{
			moving = false;
		}

		


		if (moving == true)
		{
			if (blurDistance < 10)
			{
				blurDistance += timer->getTime() * 5;
			}
			if (blurAngle < blurAng)
			{
				blurAngle += timer->getTime() * 50;
			}
			else
			{
				blurAngle -= timer->getTime() * 50;
			}
		}
		else
		{
			if (blurDistance > 1)
			{
				blurDistance -= timer->getTime()*6;
			}
		}

		if (input->isKeyDown('W') && !input->isKeyDown('S'))
		{
			moving = true;
			if (blurMult > 30)
			{
				blurMult -= timer->getTime()*40;
			}
		}
		else
		{
			if (blurMult <100)
			{
				blurMult += timer->getTime()*100;
			}
		}
	}
}

// Apply a blur outwards from the centre of the screen when moving forwards. Takes a texture parameter because it comes after an optional step in the post processing process
void App1::zoomBlur(RenderTexture* tex)
{
	XMMATRIX worldMatrix, baseViewMatrix, orthoMatrix;

	float screenSizeY = (float)zBlurTexture->getTextureHeight();
	float screenSizeX = (float)zBlurTexture->getTextureWidth();
	zBlurTexture->setRenderTarget(renderer->getDeviceContext());
	zBlurTexture->clearRenderTarget(renderer->getDeviceContext(), 0.0f, 1.0f, 1.0f, 1.0f);

	worldMatrix = renderer->getWorldMatrix();
	baseViewMatrix = camera->getOrthoViewMatrix();
	// Get the ortho matrix from the render to texture since texture has different dimensions being that it is smaller.
	orthoMatrix = directionalBlurTexture->getOrthoMatrix();

	// Render for Vertical Blur
	renderer->setZBuffer(false);
	orthoMesh->sendData(renderer->getDeviceContext());
	zBlurShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, baseViewMatrix, orthoMatrix, tex->getShaderResourceView(), screenSizeY, screenSizeX, blurMult, goggles);
	zBlurShader->render(renderer->getDeviceContext(), orthoMesh2->getIndexCount());
	renderer->setZBuffer(true);

	// Reset the render target back to the original back buffer and not the render to texture anymore.
	renderer->setBackBufferRenderTarget();
}

//Applies an angled blur effect based on movement AND kind of a wavy effect... It goes up and down
void App1::directionalBlur(RenderTexture* tex)
{
	XMMATRIX worldMatrix, baseViewMatrix, orthoMatrix;

	float screenSizeY = (float)directionalBlurTexture->getTextureHeight();
	float screenSizeX = (float)directionalBlurTexture->getTextureWidth();
	directionalBlurTexture->setRenderTarget(renderer->getDeviceContext());
	directionalBlurTexture->clearRenderTarget(renderer->getDeviceContext(), 0.0f, 1.0f, 1.0f, 1.0f);

	worldMatrix = renderer->getWorldMatrix();
	baseViewMatrix = camera->getOrthoViewMatrix();
	// Get the ortho matrix from the render to texture since texture has different dimensions being that it is smaller.
	orthoMatrix = directionalBlurTexture->getOrthoMatrix();

	// Render for Vertical Blur
	renderer->setZBuffer(false);
	orthoMesh->sendData(renderer->getDeviceContext());
	directionalBlurShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, baseViewMatrix, orthoMatrix, tex->getShaderResourceView(), screenSizeY, screenSizeX, blurAngle, blurDistance, goggles);
	directionalBlurShader->render(renderer->getDeviceContext(), orthoMesh2->getIndexCount());
	renderer->setZBuffer(true);

	// Reset the render target back to the original back buffer and not the render to texture anymore.
	renderer->setBackBufferRenderTarget();
}

//Outputs the final image
void App1::finalPass(RenderTexture* tex)
{
	// Clear the scene. (default blue colour)
	renderer->beginScene(0.39f, 0.58f, 0.92f, 1.0f);

	// RENDER THE RENDER TEXTURE SCENE
	// Requires 2D rendering and an ortho mesh.
	renderer->setZBuffer(false);
	XMMATRIX worldMatrix = renderer->getWorldMatrix();
	XMMATRIX orthoMatrix = renderer->getOrthoMatrix();  // ortho matrix for 2D rendering
	XMMATRIX orthoViewMatrix = camera->getOrthoViewMatrix();	// Default camera position for orthographic rendering

	orthoMesh->sendData(renderer->getDeviceContext());
	textShader->setShaderParameters(renderer->getDeviceContext(), worldMatrix, orthoViewMatrix, orthoMatrix, tex->getShaderResourceView());
	textShader->render(renderer->getDeviceContext(), orthoMesh->getIndexCount());	
}

//UI
void App1::gui()
{
	// Force turn off unnecessary shader stages.
	renderer->getDeviceContext()->GSSetShader(NULL, NULL, 0);
	renderer->getDeviceContext()->HSSetShader(NULL, NULL, 0);
	renderer->getDeviceContext()->DSSetShader(NULL, NULL, 0);

	// Build UI
		ImGui::Text("Torch options");
		ImGui::Checkbox("Torch Control", &torchControl);
		ImGui::Checkbox("Torch On", &torchOn);
		ImGui::SliderFloat("Torch Strength", &constF, 0.999f, 1.05f);
		ImGui::Checkbox("Torch Shadow Ortho/perspective", &torchOrtho);
		if (torchOrtho == false)
		{
			ImGui::SliderFloat("Close", &cls, 0.1f, 100.f);
		}
		

		ImGui::Text("Sun Options");
		ImGui::SliderFloat("Sun Brightness", &sunBrightness, 0.1f, 1.f);


		ImGui::Text("Blur/Post Processing Options");
		ImGui::Checkbox("Goggles (blur off entirely)", &goggles);
		ImGui::Checkbox("Motion Blur (WARNING, sometimes flashes, just keep clicking till it works)", &motBlurEffect);
		ImGui::Checkbox("Water Blur", &waterEffect);
		ImGui::Checkbox("Quote... 'Bloom'", &bloomEffect);
		ImGui::SliderFloat("Bloom Multiplier", &bloomMult, 1.f, 20.f);
		ImGui::Checkbox("Zoom blur (blur when moving forward)", &zoomBlurEffect);

		ImGui::SliderFloat("blur ang", &blurAngle, 0.f, 100.f);
		ImGui::SliderFloat("blur dist", &blurDistance, 0.f, 20.f);

		ImGui::Text("Water Options");
		ImGui::SliderFloat("Amplitude", &ampl, 0.01, 0.2f);
		ImGui::SliderFloat("Frequency", &freq, 0.5f, 5.f);
		ImGui::SliderFloat("Speed", &spe, 0.5f, 5.f);

		ImGui::Text("Underwater Options");
		if (ImGui::Button("Standard"))
		{
			waterBlurImage = 1;
		}
		if (ImGui::Button("Triangles"))
		{
			waterBlurImage = 2;
		}
		if (ImGui::Button("Pattern"))
		{
			waterBlurImage = 3;
		}
		if (ImGui::Button("Shattered"))
		{
			waterBlurImage = 4;
		}
		
	

	// Render UI
	ImGui::Render();
	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
}

