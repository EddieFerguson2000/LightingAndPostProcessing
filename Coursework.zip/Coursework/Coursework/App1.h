// Application.h
#ifndef _APP1_H
#define _APP1_H

// Includes
#include "DXF.h"
#include "ManipulationShader.h"
#include "LightShader.h"
#include "WaveBoxShader.h"
#include "TextureShader.h"
#include "ShadowShader.h"
#include "DepthShader.h"
#include "VerticalBlurShader.h"
#include "ZoomBlur.h"
#include "WaterScreen.h"
#include "BloomShader.h"
#include "HorizontalBlurShader.h"
#include "ActualVerticalBlur.h"



class App1 : public BaseApplication
{
public:

	App1();
	~App1();
	void init(HINSTANCE hinstance, HWND hwnd, int screenWidth, int screenHeight, Input* in, bool VSYNC, bool FULL_SCREEN);

	bool frame();

protected:
	void update();
	bool render();
	



	void depthPass();
	void bloomPass();
	void bloom();
	void postProcessing();
	void blurInputs();
	void zoomBlur(RenderTexture* tex);
	void directionalBlur(RenderTexture* tex);
	void horizontalBlur();
	void verticalBlur();
	void waterPPEffect(RenderTexture* tex);
	void firstPass();
	void finalPass(RenderTexture* tex);
	void checkForBlur();

	void gui();

private:
	//ManipulationShader* shader;
	DepthShader* depthShader;
	ShadowShader* shadowShader;
	TextureShader* textShader;
	LightShader* lightShader;
	WaveBoxShader* waveboxShader;
	BloomShader* bloomShader;
	ManipulationShader* manipShader;
	HorizontalBlurShader* hBlurShader;
	ActualVerticalBlurShader* aVBlurShader;
	VerticalBlurShader* directionalBlurShader;
	ZoomBlurShader* zBlurShader;
	WaterScreen* waterScreenEffect;
	PlaneMesh* mesh;
	CubeMesh* water;
	CubeMesh* lowerSand;
	CubeMesh* heatWave;
	SphereMesh* sun;
	Light* light;
	Light* torch;
	Light* volcanoLight;
	Light* anglerLight;
	AModel* fish[7];
	AModel* angler;
	AModel* torch_on;
	AModel* torch_off;
	OrthoMesh* orthoMesh;
	OrthoMesh* orthoMesh2;

	
	RenderTexture* renderTexture;
	RenderTexture* zBlurTexture;
	RenderTexture* directionalBlurTexture;
	RenderTexture* hBlurTexture;
	RenderTexture* aVBlurTexture;
	RenderTexture* waterPPTexture;
	RenderTexture* bloomTexture;
	RenderTexture* bloomPassTexture;
	ID3D11RasterizerState* NoCullFrame;
	ID3D11RasterizerState* BackCullFrame;

	ShadowMap* shadowMap;
	ShadowMap* shadowMap2;

	float angXYZ[3];
	float cone = 0;
	float pitch, yaw, roll;
	float x;
	float time;
	float ampl = 0.1;
	float freq = 2;
	float spe = 1;

	float sunBrightness = 1.f;

	float underWaterTimer = 1.f;

	float lightX;
	float lightZ;
	float quadF = 0.f;
	float constF = 1.025f;
	float linF = 0.125;;


	float torchTranslate[3];
	float torchRotate[3];


	float l2Y, l2Z;

	bool torchControl = true;
	bool torchOn = true;
	bool torchOrtho = true;

	//blur variables
	bool blurCheck = false;
	bool goggles = false;
	float blurAngle = 149.f;
	float blurDistance = 5.f;
	bool blurDir = false;
	float blurMult = 100.f;
	bool bloomEffect = true;
	bool motBlurEffect = false;
	bool waterEffect = true;
	bool zoomBlurEffect = true;

	bool moving = false;

	float bloomMult = 3;
	float cls = 25.f;
	int waterBlurImage = 1;

};

#endif