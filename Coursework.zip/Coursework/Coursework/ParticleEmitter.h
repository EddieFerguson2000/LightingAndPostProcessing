#pragma once
#include "DXF.h"

using namespace std;

class ParticleEmitter
{

private:
	vector<QuadMesh> particles;



};

