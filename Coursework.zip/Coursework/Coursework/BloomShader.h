#pragma once

#include "BaseShader.h"

using namespace std;
using namespace DirectX;

class BloomShader : public BaseShader
{
public:
	BloomShader(ID3D11Device* device, HWND hwnd);
	~BloomShader();

	void setShaderParameters(ID3D11DeviceContext* deviceContext, const XMMATRIX& world, const XMMATRIX& view, const XMMATRIX& projection, ID3D11ShaderResourceView* bloomTexture, ID3D11ShaderResourceView* sceneTexture, float width, float height);

private:
	struct ScreenSizeBufferType
	{
		float screenWidth;
		float screenHeight;
		XMFLOAT2 padding;
	};

	void initShader(const wchar_t* vs, const wchar_t* ps);

private:
	ID3D11Buffer* matrixBuffer;
	ID3D11Buffer* screenSizeBuffer;
	ID3D11SamplerState* sampleState;
};

