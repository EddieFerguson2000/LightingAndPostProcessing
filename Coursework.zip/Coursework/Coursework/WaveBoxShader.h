#pragma once

#include "DXF.h"

using namespace std;
using namespace DirectX;

class WaveBoxShader : public BaseShader
{
private:
	struct TimeBufferType
	{
		float dt;
		float frequency;
		float amplitude;
		float speed;
	};

public:
	WaveBoxShader(ID3D11Device* device, HWND hwnd);
	~WaveBoxShader();

	void setShaderParameters(ID3D11DeviceContext* deviceContext, const XMMATRIX& world, const XMMATRIX& view, const XMMATRIX& projection, ID3D11ShaderResourceView* texture, float t, float f, float a, float s);

private:
	void initShader(const wchar_t* cs, const wchar_t* ps);

private:
	ID3D11Buffer* matrixBuffer;
	ID3D11SamplerState* sampleState;
	ID3D11Buffer* timeBuffer;

};

